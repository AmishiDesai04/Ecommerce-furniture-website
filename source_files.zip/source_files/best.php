<!doctype html>
<html class="no-js" lang="en">

    <head>
        <!-- meta data -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

        <!--font-family-->
		<link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">
        
        <!-- title of site -->
        <title>Couch Potato</title>

        <!-- For favicon png -->
		<link rel="shortcut icon" type="image/icon" href="assets/logo/favicon.png"/>
       
        <!--font-awesome.min.css-->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">

        <!--linear icon css-->
		<link rel="stylesheet" href="assets/css/linearicons.css">

		<!--animate.css-->
        <link rel="stylesheet" href="assets/css/animate.css">

        <!--owl.carousel.css-->
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
		<link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
		
        <!--bootstrap.min.css-->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
		
		<!-- bootsnav -->
		<link rel="stylesheet" href="assets/css/bootsnav.css" >	
        
        <!--style.css-->
        <link rel="stylesheet" href="assets/css/mainshoppg.css">
        
        <!--responsive.css-->
        <link rel="stylesheet" href="assets/css/responsive.css">

        <script>
		document.getElementsByTagName("html")[0].className += " js";
	 </script>
	 <link rel="stylesheet" href="new assets/css/style.css">
        
        
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		
        <!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
			<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
        <script>/* When the user clicks on the button,    toggle between hiding and showing the dropdown content */
    /*function myFunction() 
        {
            document.getElementById("myDropdown").classList.toggle("show");
        }// Close the dropdown if the user clicks outside of it    
        window.onclick = function (event) 
        { if (!event.target.matches('.dropbtn')) 
            {
                var dropdowns = document.getElementsByClassName("dropdown-content");
                var i;
                for (i = 0; i < dropdowns.length; i++) 
                {
                     var openDropdown = dropdowns[i];
                     if (openDropdown.classList.contains('show')) 
                     {
                        openDropdown.classList.remove('show');
                    }
                }
            }
        }*/
        function myFunction1()
        {
            document.getElementById("myDropdown1").classList.toggle("show");
        }
        window.onclick = function(event)
        {
            if(!event.target.matches('.dropbtn1'))
            {
                var dropdowns1 = document.getElementsByClassName("dropdown-content1");
                var i;
                
                for (i = 0; i < dropdowns1.length; i++) 
                {
                    var openDropdown = dropdowns1[i];
                    if (openDropdown.classList.contains('show')) 
                    {   
                        openDropdown.classList.remove('show');
                    }
                    
                }
            }
         }
        </script>

    </head>
	
	<body>
	
		
		
	
		
	
        <header>
			<!-- top-area Start -->
			<div class="top-area">
				<div class="header-area">
					<!-- Start Navigation -->
				    <nav class="navbar navbar-default bootsnav  navbar-sticky navbar-scrollspy"  data-minus-value-desktop="70" data-minus-value-mobile="55" data-speed="1000">


				            <!-- End Atribute Navigation -->

				            <!-- Start Header Navigation -->
				            <div class="navbar-header">
				                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
				                    <i class="fa fa-bars"></i>
				                </button>
				                <a class="navbar-brand" href="index.php" style="padding-left: 20px;">Couch<span> Potato</span>.</a>

				            </div><!--/.navbar-header-->
				            <!-- End Header Navigation -->

				            <!-- Collect the nav links, forms, and other content for toggling -->
				            <div class="collapse navbar-collapse menu-ui-design" id="navbar-menu">
				                <ul class="nav navbar-nav navbar-center" data-in="fadeInDown" data-out="fadeOutUp">
				                    <li class=" scroll"><input type="button" value="Home" onclick="window.location.href='index.php'" class="home-btn" style="background-color:white;
    color: #e99c2e;
    padding-top: 47px;
    width: 80px;
    height: 70px;
    border: none;
    border-radius: 4px;
    font-size: 16px;
    cursor: pointer;"></li>
				                    <li class="scroll active"><a href="mainshop3.php">shop</a></li>
				                    
				                </ul><!--/.nav -->
				            </div><!-- /.navbar-collapse -->
				        </div><!--/.container-->
				    </nav><!--/nav-->
				    <!-- End Navigation -->
				</div><!--/.header-area-->
			    <div class="clearfix"></div>

			</div><!-- /.top-area-->
			<!-- top-area End -->

		</header><!--/.welcome-hero-->
		<!--welcome-hero end -->
        
    
            <main class="container-fluid" >
                <header class="productheader" >
                    
                    <ul class="indicator" >
                        <li data-filter="all" class="active"><a href="mainshop3.php">All</a></li>
                        <li data-filter="Chairs"><a href="chairfake.php">Chairs</a></li>
                        <li data-filter="Beds"><a href="bedfake.php">Beds</a></li>
                        <li data-filter="Tables"><a href="tablefake.php">Tables</a></li>
                        <li data-filter="Sofas"><a href="sofafake.php">Sofas</a></li>
                   
                    </ul>
                  
                    <ul class="dropdown">
				        <a href="#" class="dropdown-toggle" data-toggle="dropdown" >
				            <span style="padding-right: 100px;">Filter ˅</span>
						</a>
				        <ul class="dropdown-menu cart-list s-cate" >
				            <li class="single-cart-list">
				                <div class="cart-list-txt" >
				                  	<h6><a href="bedlh.php">Bestsellers</a>
                                </div>  
				            </li>
                            <li class="single-cart-list">
				                <div class="cart-list-txt" >
				                  	<h6><a href="mainlh.php">Low to High</a>
                                </div>  
				            </li>
                        </ul>
                        
                            
			            
        </ul><!--/.dropdown-->
				                
                    <!---<div class="filter-condition" style="float: right;">
                        <button onclick="myFunction1()" class="dropbtn1">Sorting</button>
                        <div id="myDropdown1" class="dropdown-content1">
                            <a href="bedlh.php">Low-To-High</a>
                            <a href="high-low.html">High-To-Low</a>
                            <a href="product1.html">Default</a>
                         </div>
                    </div>--->
                </header>




        <!------------------------------------------------------------------------------ALLPRODUCTS PRODUCTS ------> 
        <div class="new-arrivals-content">
            
            <ul class="items">
            

            <div class="row">
                <div class="col-md-3 col-sm-4">
                    <div class="single-new-arrival">
                        <div class="single-new-arrival-bg">
			                
				                <li data-category="" data-price="">
					                <picture>
						                <img src="assets/images/collection/6.png" alt="new-arrivals images">
					                </picture>
                                    <div class="detail">
                                        <h4><a href="table_wooden.php">Wooden Table Set</a></h4>
                                    </div>
                                    <p class="arrival-product-price">Rs. 18200.00 </p>
                                    <button class="icon-link cd-add-to-cart js-cd-add-to-cart" data-price="18200" product-model="Wooden Table Set" product-image="assets/images/collection/6.png" style="color:white;border-radius: 5px;
    border: 1px solid white;
    padding: 10px 20px;
    background: #e99c2e;">Add to Cart</button>
                                </li>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-4">
                    <div class="single-new-arrival">
                        <div class="single-new-arrival-bg">

                                <li data-category="" data-price="">
					                <picture>
						                <img src="assets/images/collection/13.png" alt="new-arrivals images">
					                </picture>
                                    <div class="detail">
                                        <h4><a href="sofa_velvetblue.php">Velvet Blue Sofa</a></h4>
                                    </div>
                                    <p class="arrival-product-price">Rs. 13250.00 </p>
                                    <button class="icon-link cd-add-to-cart js-cd-add-to-cart" data-price="13250" product-model="Velvet Blue Sofa" product-image="assets/images/collection/13.png" style="color:white;border-radius: 5px;
    border: 1px solid white;
    padding: 10px 20px;
    background: #e99c2e;">Add to Cart</button>
                                </li>
                            </div>
                        </div>
                    </div>
            
                    <div class="col-md-3 col-sm-4">
                        <div class="single-new-arrival">
                            <div class="single-new-arrival-bg">
    
                                    <li data-category="" data-price="">
                                        <picture>
                                            <img src="assets/images/collection/bed2.png" alt="new-arrivals images">
                                        </picture>
                                        <div class="detail">
                                            <h4><a href="bed_sky.php">Sky Bed</a></h4>
                                        </div>
                                        <p class="arrival-product-price">Rs. 45000.00 </p>
                                        <button class="icon-link cd-add-to-cart js-cd-add-to-cart" data-price="45000" product-model="Sky Bed" product-image="assets/images/collection/bed2.png" style="color:white;border-radius: 5px;
    border: 1px solid white;
    padding: 10px 20px;
    background: #e99c2e;">Add to Cart</button>
                                    </li>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-4">
                            <div class="single-new-arrival">
                                <div class="single-new-arrival-bg">
        
                                        <li data-category="" data-price="">
                                            <picture>
                                                <img src="assets/images/collection/9.png" alt="new-arrivals images">
                                            </picture>
                                            <div class="detail">
                                                <h4><a href="table_bar.php">Bar Table</a></h4>
                                            </div>
                                            <p class="arrival-product-price">Rs. 12500.00 </p>
                                            <button class="icon-link cd-add-to-cart js-cd-add-to-cart" data-price="12500" product-model="Bar Table" product-image="assets/images/collection/9.png" style="color:white;border-radius: 5px;
    border: 1px solid white;
    padding: 10px 20px;
    background: #e99c2e;">Add to Cart</button>
                                        </li>
                                    </div>
                                </div>
                            </div>
            </div>

            <div class="row">
                <div class="col-md-3 col-sm-4">
                    <div class="single-new-arrival">
                        <div class="single-new-arrival-bg">
			                
				                <li data-category="" data-price="">
					                <picture>
						                <img src="assets/images/collection/whitechair.png" alt="new-arrivals images">
					                </picture>
                                    <div class="detail">
                                        <h4><a href="chair_snowwhite.php">Snow-White Armchair</a></h4>
                                    </div>
                                    <p class="arrival-product-price">Rs. 5000.00 </p>
                                    <button class="icon-link cd-add-to-cart js-cd-add-to-cart" data-price="5000" product-model="Snow-White Armchair" product-image="assets/images/collection/whitechair.png" style="color:white;border-radius: 5px;
    border: 1px solid white;
    padding: 10px 20px;
    background: #e99c2e;">Add to Cart</button>
                                </li>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-4">
                    <div class="single-new-arrival">
                        <div class="single-new-arrival-bg">

                                <li data-category="" data-price="">
					                <picture>
						                <img src="assets/images/collection/14.png" alt="new-arrivals images">
					                </picture>
                                    <div class="detail">
                                        <h4><a href="sofa_mustardyellow.php">Mustard Yellow Sofa</a></h4>
                                    </div>
                                    <p class="arrival-product-price">Rs. 17540.00 </p>
                                    <button class="icon-link cd-add-to-cart js-cd-add-to-cart" data-price="17540" product-model="Mustard Yellow Sofa" product-image="assets/images/collection/14.png" style="color:white;border-radius: 5px;
    border: 1px solid white;
    padding: 10px 20px;
    background: #e99c2e;">Add to Cart</button>
                                </li>
                            </div>
                        </div>
                    </div>
            
                    <div class="col-md-3 col-sm-4">
                        <div class="single-new-arrival">
                            <div class="single-new-arrival-bg">
    
                                    <li data-category="" data-price="">
                                        <picture>
                                            <img src="assets/images/collection/bed3.png" alt="new-arrivals images">
                                        </picture>
                                        <div class="detail">
                                            <h4><a href="bed_pullover">Pull Over Bed</a></h4>
                                        </div>
                                        <p class="arrival-product-price">Rs. 22000.00 </p>
                                        <button class="icon-link cd-add-to-cart js-cd-add-to-cart" data-price="22000" product-model="Pull Over Bed" product-image="assets/images/collection/bed3.png" style="color:white;border-radius: 5px;
    border: 1px solid white;
    padding: 10px 20px;
    background: #e99c2e;">Add to Cart</button>
                                    </li>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-4">
                            <div class="single-new-arrival">
                                <div class="single-new-arrival-bg">
        
                                        <li data-category="" data-price="">
                                            <picture>
                                                <img src="assets/images/collection/arrivals5.png" alt="new-arrivals images">
                                            </picture>
                                            <div class="detail">
                                                <h4><a href="chair_redvelvet">Red-Velvet Chair</a></h4>
                                            </div>
                                            <p class="arrival-product-price">Rs. 5700.00 </p>
                                            <button class="icon-link cd-add-to-cart js-cd-add-to-cart" data-price="5700" product-model="Red-Velvet Chair" product-image="assets/images/collection/arrivals5.png" style="color:white;border-radius: 5px;
    border: 1px solid white;
    padding: 10px 20px;
    background: #e99c2e;">Add to Cart</button>
                                        </li>
                                    </div>
                                </div>
                            </div>
            </div>

            

            
		</ul>
        </div>
               

    



		<!--footer start-->
		<footer id="footer"  class="footer">
			<div class="container">
				<div class="hm-footer-copyright text-center">
					<div class="footer-social">
                    <a href="https://www.facebook.com/" style="padding-right: 10px;"><i class="fa fa-facebook"></i></a>	
						<a href="https://www.instagram.com/" style="padding-right: 10px;"><i class="fa fa-instagram"></i></a>
						<a href="https://www.linkedin.com/feed/" style="padding-right: 10px;"><i class="fa fa-linkedin"></i></a>
						<a href="https://in.pinterest.com/" style="padding-right: 10px;"><i class="fa fa-pinterest"></i></a>
						<a href="https://www.behance.net/" style="padding-right: 10px;"><i class="fa fa-behance"></i></a>		
					</div>
					
				</div><!--/.text-center-->
			</div><!--/.container-->

			<div id="scroll-Top">
				<div class="return-to-top">
					<i class="fa fa-angle-up " id="scroll-top" data-toggle="tooltip" data-placement="top" title="" data-original-title="Back to Top" aria-hidden="true"></i>
				</div>
				
			</div><!--/.scroll-Top-->
        </div>
        </footer><!--/.footer-->
		<!--footer end-->
		
		<div class="cd-cart cd-cart--empty js-cd-cart">
			<a href="#0" class="cd-cart__trigger text-replace">
	  
			    <ul class="cd-cart__count">
				   <!-- cart items count -->
				   <li>0</li>
				   <li>0</li>
			    </ul>
			    <!-- .cd-cart__count -->
			</a>
	  
			<div class="cd-cart__content">
			    <div class="cd-cart__layout">
				   <header class="cd-cart__header">
					  <h2>Cart</h2>
					  <span class="cd-cart__undo">Item removed. <a href="#0">Undo</a></span>
				   </header>
	  
				   <div class="cd-cart__body">
					  <ul>
						 <!-- products added to the cart will be inserted here using JavaScript -->
					  </ul>
				   </div>
	  
				   <footer class="cd-cart__footer">
					  <a href="payment.php" class="cd-cart__checkout">
						 <em>Checkout - Rs.<span>0</span>
				   <svg class="icon icon--sm" viewBox="0 0 24 24" src="new assets/img/cart.svg">   </svg>
				 </em>
					  </a>
				   </footer>
			    </div>
			</div>
			<!-- .cd-cart__content -->
		 </div>
		 <!-- cd-cart -->
		 <script src="new assets/js/util.js"></script>
		 <!-- util functions included in the CodyHouse framework -->
		 <script src="new assets/js/main.js"></script>
		
		
		<!-- Include all js compiled plugins (below), or include individual files as needed -->

		<script src="assets/js/jquery.js"></script>
        
        <!--modernizr.min.js-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
		
		<!--bootstrap.min.js-->
        <script src="assets/js/bootstrap.min.js"></script>
		
		<!-- bootsnav js -->
		<script src="assets/js/bootsnav.js"></script>

		<!--owl.carousel.js-->
        <script src="assets/js/owl.carousel.min.js"></script>


		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
		
        
        <!--Custom JS-->
        <script src="assets/js/custom.js"></script>
        
    </body>
	
</html>

<script type="text/javascript" src="main.js"></script> 