<?php
    $sql = "SELECT Name, Surname, Email, Subject, Message FROM reachout_table";
    $result = $mysqli->query($sql);
    echo "<br>";
    if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "Name: " . $row["Name"]. "<br>Surname: " . $row["Surname"]. "<br>Email:" . $row["Email"]. "<br>Subject:". $row["Subject"]."<br>Message:".$row["Message"];
    }
    } else {
    echo "0 results";
    }


?>