var counter = 0;

