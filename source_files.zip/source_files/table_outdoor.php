<!doctype html>
<html class="no-js" lang="en">

    <head>
        <!-- meta data -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

        <!--font-family-->
		<link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">
        
        <!-- title of site -->
        <title>Couch Potato</title>

        <!-- For favicon png -->
		<link rel="shortcut icon" type="image/icon" href="assets/logo/favicon.png"/>
       
        <!--font-awesome.min.css-->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">

        <!--linear icon css-->
		<link rel="stylesheet" href="assets/css/linearicons.css">

		<!--animate.css-->
        <link rel="stylesheet" href="assets/css/animate.css">

        <!--owl.carousel.css-->
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
		<link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
		
        <!--bootstrap.min.css-->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
		
		<!-- bootsnav -->
		<link rel="stylesheet" href="assets/css/bootsnav.css" >	
        
        <!--style.css-->
        <link rel="stylesheet" href="assets/css/mainshoppg.css">
        
        <!--responsive.css-->
        <link rel="stylesheet" href="assets/css/responsive.css">
        
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		
        <!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
			<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

    </head>
	
	<body>
	
		
		
	
		
	
        <header>
			<!-- top-area Start -->
			<div class="top-area">
				<div class="header-area">
					<!-- Start Navigation -->
				    <nav class="navbar navbar-default bootsnav  navbar-sticky navbar-scrollspy"  data-minus-value-desktop="70" data-minus-value-mobile="55" data-speed="1000">


				        <div class="container">            
				            <!-- Start Atribute Navigation -->
				            <div class="attr-nav">
				                <ul>
				                
				                </ul>
				            </div><!--/.attr-nav-->
				            <!-- End Atribute Navigation -->

				            <!-- Start Header Navigation -->
				            <div class="navbar-header">
				                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
				                    <i class="fa fa-bars"></i>
				                </button>
				                <a class="navbar-brand" href="index.php">Couch<span> Potato</span>.</a>

				            </div><!--/.navbar-header-->
				            <!-- End Header Navigation -->

				            <!-- Collect the nav links, forms, and other content for toggling -->
				            <div class="collapse navbar-collapse menu-ui-design" id="navbar-menu">
				                <ul class="nav navbar-nav navbar-center" data-in="fadeInDown" data-out="fadeOutUp">
				                    <li class=" scroll"><input type="button" value="Home" onclick="window.location.href='index.php'" class="home-btn" style="background-color:white;
    color: #e99c2e;
    padding-top: 47px;
    
    width: 80px;
    height: 70px;
    border: none;
    border-radius: 4px;
    font-size: 16px;
    cursor: pointer;"></li>
				                   <!-- <li class="scroll active"><a href="mainshop2.php">shop</a></li>-->
									<li data-filter="Sofas"><a href="mainshop3.php">shop</a></li>
				                    
				                </ul><!--/.nav -->
				            </div><!-- /.navbar-collapse -->
				        </div><!--/.container-->
				    </nav><!--/nav-->
				    <!-- End Navigation -->
				</div><!--/.header-area-->
			    <div class="clearfix"></div>

			</div><!-- /.top-area-->
			<!-- top-area End -->

		</header><!--/.welcome-hero-->
		<!--welcome-hero end -->
        
    
            
                <main class="small-container">
				
                    <div class="row">
                        <div class="col-sm-6" style="padding-left: 250px;padding-top: 50px;padding-bottom: 100px;">
                            <img src="assets/images/collection/7.png" width="450" height="450">
                        </div>
                        <div class="col-sm-6" style="padding-left: 100px; "><br><br><br><br>
                            <u><p>Shop / Outdoor Table Set</p></u>
							<p style="font-size: 50px; font-weight: bold;color: #e99c2e;">Outdoor Table Set</p>
							<h4>Rs. 6200</h4><br>
							<p style="font-size: small;padding-right: 100px;text-align: justify;">The snow white chair is a chic and elegant seating option that features a clean, minimalist design with a bright white finish. Whether used as an accent piece or as part of a larger seating arrangement, the snow white chair is sure to add a touch of class and sophistication to your decor. </p>
							<p style="font-size: small;padding-right: 100px;text-align: justify; font-weight: bold;">Height: 28 inches, Width: 22 inches, Depth: 20 inches</p><br>
							
							<style>
								.btn-cart.welcome-add-cart,.btn-cart.welcome-add-cart.welcome-more-info {
									width: 170px;
									height: 60px;
									line-height: 60px;
									border-radius: 1px;
									font-size: 16px;
									font-weight: 500;
									display: inline-block;
									margin-top: 34px;
									-webkit-transition: 0.3s linear; 
									-moz-transition: 0.3s linear; 
									-ms-transition: 0.3s linear; 
									-o-transition: 0.3s linear; 
									transition: 0.3s linear;
									border: 1px solid #e99c2e;
								}
								.btn-cart.welcome-add-cart span {
									text-transform:  lowercase;
									
								}
								.btn-cart.welcome-add-cart span.lnr.lnr-plus-circle {
									position:  relative;
									top: 0px;
									font-size: 16px;
									margin-right: 5px;
									
								}
								.btn-cart.welcome-add-cart.welcome-more-info{
									color: #e99c2e;
									background: #fff;
									border:#e99c2e;
									
								}
								.btn-cart.welcome-add-cart:hover{
									color: #fff;
									background: #e99c2e;
									border: 1px solid #e99c2e;
								}
								.btn-cart.welcome-add-cart.welcome-more-info:hover{
									color: #e99c2e;
									background: transparent;
									border: 1px solid #e99c2e;
								}
							</style>
						</div>
                    </div>
                <hr>
				<div class="row">
					<div >
						<div class="product-page-review" style="padding-left:50px; width: 50%">
						<form>
						<fieldset class="col-sm-4" style="width:500px ;border: solid 2px #e99c2e; padding-left:50px;padding-top:50px;padding-bottom:50px">
						<h3 style="color: #e99c2e; font-family:'Roboto', sans-serif; font-size: 30px;">Write a Review</h3><br>
							<label for="name">Name:</label><br>
							<input type="text"id="name" name="name" 
										style="
										height: 46px;
										border-radius: 5px;
										background-color: transparent;
										border: 2px solid #cac1b7;
										outline: none;
										font-size: 15px;
										font-weight: 300;
										color: #2a2a2a;
										padding: 0px 10px;
										margin-bottom: 20px;"><br>
							<label for="review">Product Review:</label><br>
							<textarea id="review" name="review" style="
										height: 100px;
										width: 300px;
										border-radius: 5px;
										background-color: transparent;
										border: 2px solid #cac1b7;
										outline: none;
										font-size: 15px;
										font-weight: 300;
										color: #2a2a2a;
										padding: 0px 10px;
										margin-bottom: 20px;"></textarea><br>
							<label for="rating">Product Rating:</label><br>
							<input type="number" id="rating" name="rating" min="1" max="10" style="
										height: 46px;
										border-radius: 5px;
										background-color: transparent;
										border: 2px solid #cac1b7;
										outline: none;
										font-size: 15px;
										font-weight: 300;
										color: #2a2a2a;
										padding: 0px 10px;
										margin-bottom: 20px;"><br>
							<button type="submit" style="background-color: #e99c2e; font-weight:bold;color: #fff; border-radius: 30px; height: 40px; width: 180px;">Submit Review</button>
						</form>
						</fieldset>
					</div>
					<fieldset class="col-sm-8" style=" width:55% ;border: solid 2px #e99c2e; padding-left:50px;padding-top:50px;padding-bottom:50px">
					<div  style="width: 50%">
						<div id="reviews">
						<h2 style="color: #e99c2e; font-family:'Roboto', sans-serif; font-size: 30px;">Reviews:</h2>
						<ul id="review-list"></ul>
						</div>
					</div>
					</fieldset>
				</div>

					<script>
					const nameInput = document.getElementById('name');
					const reviewInput = document.getElementById('review');
					const ratingInput = document.getElementById('rating');
					const reviewList = document.getElementById('review-list');

					// Load previous reviews from localStorage or initialize an empty array
					const reviews = JSON.parse(localStorage.getItem('reviews')) || [];

					// Display existing reviews
					//localStorage.clear();
					reviews.forEach(review => {
						
						const li = document.createElement('li');
						li.textContent = `@${review.name}`;
						reviewList.appendChild(li);
						const ni = document.createElement('ni');
						ni.textContent = ` Rating: ${review.rating}`;
						reviewList.appendChild(ni);
						const mi = document.createElement('mi');
						mi.textContent = ` Review: ${review.text}`;
						reviewList.appendChild(mi);
						const pi = document.createElement('pi');
						pi.textContent = `\n*********************************************************\n`;
						reviewList.appendChild(pi);
						
						
					});

					// Add event listener to the form to handle submission
					document.querySelector('form').addEventListener('submit', (event) => {
						event.preventDefault(); // prevent page reload on submit

						// Get the new review data
						const review = {
						name: nameInput.value,
						text: reviewInput.value,
						rating: ratingInput.value
						};

						// Add the new review to the reviews array and update localStorage
						reviews.push(review);
						localStorage.setItem('reviews', JSON.stringify(reviews));

						// Create a new li element to display the review
						const li = document.createElement('li');
						li.textContent = `@${review.name}`;
						reviewList.appendChild(li);
						const ni = document.createElement('ni');
						ni.textContent = ` Rating: ${review.rating}`;
						reviewList.appendChild(ni);
						const mi = document.createElement('mi');
						mi.textContent = ` Review: ${review.text}`;
						reviewList.appendChild(mi);
						const pi = document.createElement('pi');
						pi.textContent = `\n*********************************************************\n`;
						reviewList.appendChild(pi);

						// Add the new li element to the review list
						
						

						// Clear the form inputs
						nameInput.value = '';
						reviewInput.value = '';
						ratingInput.value = '';
					});
					</script>


				
				
				
				</main>

				


        
           
               

    



		<!--footer start-->
		<footer id="footer"  class="footer">
			<div class="container">
				<div class="hm-footer-copyright text-center">
				<div class="footer-social"><br>
                    <a href="https://www.facebook.com/" style="padding-right: 10px;"><i class="fa fa-facebook"></i></a>	
						<a href="https://www.instagram.com/" style="padding-right: 10px;"><i class="fa fa-instagram"></i></a>
						<a href="https://www.linkedin.com/feed/" style="padding-right: 10px;"><i class="fa fa-linkedin"></i></a>
						<a href="https://in.pinterest.com/" style="padding-right: 10px;"><i class="fa fa-pinterest"></i></a>
						<a href="https://www.behance.net/" style="padding-right: 10px;"><i class="fa fa-behance"></i></a>		
					</div>
					
				</div><!--/.text-center-->
			</div><!--/.container-->

			<div id="scroll-Top">
				<div class="return-to-top">
					<i class="fa fa-angle-up " id="scroll-top" data-toggle="tooltip" data-placement="top" title="" data-original-title="Back to Top" aria-hidden="true"></i>
				</div>
				
			</div><!--/.scroll-Top-->
        </div>
        </footer><!--/.footer-->
		<!--footer end-->
		
		
		
		<!-- Include all js compiled plugins (below), or include individual files as needed -->

		<script src="assets/js/jquery.js"></script>
        
        <!--modernizr.min.js-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
		
		<!--bootstrap.min.js-->
        <script src="assets/js/bootstrap.min.js"></script>
		
		<!-- bootsnav js -->
		<script src="assets/js/bootsnav.js"></script>

		<!--owl.carousel.js-->
        <script src="assets/js/owl.carousel.min.js"></script>


		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
		
        
        <!--Custom JS-->
        <script src="assets/js/custom.js"></script>
        
    </body>
	
</html>

<script type="text/javascript" src="main.js"></script>