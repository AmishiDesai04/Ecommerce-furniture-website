<?php
    $host = "localhost";
    $username = "root";
    $user_pass = "usbw";
    $database_in_use = "email_database";

    $mysqli = mysqli_connect($host,$username,$user_pass,$database_in_use);
    
    if(isset($_POST['submit']))
    {    
        $new_email= $_POST["emailsub"];
        
        $sqli = "INSERT INTO email_subscription (Email) VALUE ('$new_email')";
        if(mysqli_query($mysqli, $sqli)) 
        {
            echo '<script>alert("Email added to subscription list successfully!")</script>';
          } else 
          {
            echo "Error: " . mysqli_error($mysqli);
          }
        mysqli_close($mysqli);
    }
?>